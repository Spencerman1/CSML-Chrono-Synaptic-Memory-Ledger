“File previously named LICENSE.md has been renamed to reflect its true function as a governance and sovereign IP notice, not a software license. No rights were granted at any time.”

CSML™ is a proprietary internal system design and governance model. References to enforcement, logging, or jurisdiction describe internal IP governance and evidentiary intent, not an assertion of public regulatory authority.

This file is a notice of ownership and governance. It does not grant any license, rights, or permissions of any kind.

# CSML™ Sovereign Governance Agreement

**Chrono-Synaptic Memory Ledger (CSML™)**  
© 2025 Spencer Southern | Southern Star Pro. Studios L.L.C.

## Terms of Use

The CSML™ protocol is the official timestamp and behavioral memory system of the Mint-to Logic™ framework.

You MAY NOT:
- Clone or fork this protocol to build alternative behavioral memory chains  
- Simulate behavioral timestamp ledgers for credential or AI activity  
- Create derivative works without written license through RSLL™

You MAY:
- Request a sovereign license  
- Use for academic citation or non-commercial research with attribution

---

**All use must be licensed through RSLL™ and enforced by RBGA™.**  
**This is a protected sovereign behavioral memory system.**
